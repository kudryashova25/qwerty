
const makeItFunny = (str, n) => {
  let i=0;
  let result ="";
  while ( i < str.length ) {
    const current = str[i]
  }
}

//alert( 'Interface'[0].toLowerCase() ); // 'i' https://learn.javascript.ru/string#dostup-k-simvolam