# getNumberExplanation 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ufxhyung-the-reactor/pen/WNLRLww](https://codepen.io/ufxhyung-the-reactor/pen/WNLRLww).

при вводе числа 666, 47, 7 выводится определенные ответы.
сделай тест-кейс в monday